package kr.or.ddit.study06.sec06;

public class AcessProtect {
	protected int a;
	protected void protectedMethod1() {
		
	}
}
