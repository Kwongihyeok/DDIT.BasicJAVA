package kr.or.ddit.study06.sec06;

import java.util.Scanner;

public class PersonMain {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		Person p1 = new Person();
		p1.name = "이름";
		int age = sc.nextInt();
		if(age < 0) {
			System.out.println("유효한 나이를 입력해주세요.");
		}else {
			p1.age = age;
		}
		
		
	}
}
