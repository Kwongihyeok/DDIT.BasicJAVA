package kr.or.ddit.study06.sec06;

public class AcessDefault {
	int a;
	void defaultMethod1() {
		
	}
	
	void defalutMethod2() {
		
	}
}
