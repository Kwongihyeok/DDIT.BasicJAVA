package kr.or.ddit.study06.sec06;

public class AcessPublic {
	public int a;
	public void publicMethod1() {
		
	}
}
