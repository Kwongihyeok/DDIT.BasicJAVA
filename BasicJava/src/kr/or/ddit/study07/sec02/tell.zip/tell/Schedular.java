package kr.or.ddit.study07.sec02.tell;

public class Schedular {
	public void getNextCall() {
		
	}
	public void sendCallToAgent() {
		
	}
}
